/*
  ==============================================================================

    PlaylistComponent.h
    Created: 11 Mar 2021 12:44:22pm
    Author:  nicob

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include <vector>
#include <string>
#include "DJAudioPlayer.h"
#include  "WaveformDisplay.h"
#include "DeckGUI.h"

using namespace juce;


//==============================================================================
/*
*/
class PlaylistComponent  : public juce::Component,
                           public  TableListBoxModel,
                           public Button::Listener
{
public:
    PlaylistComponent();
    ~PlaylistComponent() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    int getNumRows() override;

    void paintRowBackground(Graphics&,
                            int rowNumber,
                            int width,
                            int height,
                            bool rowIsSelected) override;
    void paintCell(Graphics&,
                            int rowNumber,
                            int columnId,
                            int width,
                            int height,
                            bool rowIsSelected) override;

    Component* refreshComponentForCell(int rowNumber,
        int columnId,
        bool isRowSelected,
        Component* existingComponentToUpdate) override;

    void buttonClicked(Button* button) override;

    //this is for loading the new one
    void loadURL(URL audioURL);


private:

    TableListBox tableComponent;
    std::vector<std::string> trackTitles;
    std::vector<std::string> trackArtist;

    
//new ones for opening a file
 /*   std::vector<std::string> trackArtist;
    TextButton loadButton{ "LOAD" };
    DJAudioPlayer* player;
    WaveformDisplay waveformDisplay;*/


    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PlaylistComponent)
};
