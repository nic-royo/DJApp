/*
  ==============================================================================

    MidiSeq.cpp
    Created: 14 Mar 2021 1:29:00pm
    Author:  nicob

  ==============================================================================
*/

#include <JuceHeader.h>
#include "MidiSeq.h"
#include "DeckGUI.h"
using namespace juce;


//==============================================================================
MidiSeq::MidiSeq()
{
    // In your constructor, you should add any child components, and
    // initialise any special settings that your component needs.

}

MidiSeq::~MidiSeq()
{
}

void MidiSeq::paint (juce::Graphics& g)
{
   //Here we will input all of our code for the circles.
    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));   // clear the background

    g.setColour (juce::Colours::forestgreen);
    g.drawRect (getLocalBounds(), 1);   // draw an outline around the component

    g.setColour (juce::Colours::white);
    g.setFont (20.0f);
    g.drawText ("Welcome to my app!", getLocalBounds(),
                juce::Justification::centred+2, true);   // draw some placeholder text

// Here I will try to make circles that move with the audio tracks, I created an integer variable that takes the function getTempoSecondsPerQuarterNote from the midiMessage class
    //to display a circle with a different size depending on the audio being played.
    int r1 = midiTempo.getTempoSecondsPerQuarterNote();
    int v1 = rand() % 20;         // random numer in the range to 50
    g.setColour(juce::Colours::darkred);
    g.drawEllipse(getWidth() * 0.25, getHeight() * 0.25, 100, 100, r1+10);
//As we can see, I implemented it in the last argument, which is responsible for the line thickness of the circle, I belive this was a good way to show how the audio increases or decreases.
    
    int v2 = rand() % 40;         // v1 in the range 0 to 40
    g.setColour(juce::Colours::aqua);
    g.drawEllipse(getWidth() * 0.75, getHeight() * 0.25, 100, 100, v2);
}

void MidiSeq::resized()
{
    // This method is where you should set the bounds of any child
    // components that your component contains..

}


