/*
  ==============================================================================

    PlaylistComponent.cpp
    Created: 11 Mar 2021 12:44:22pm
    Author:  nicob

  ==============================================================================
*/

#include <JuceHeader.h>
#include "PlaylistComponent.h"
#include "DeckGUI.h"



//==============================================================================
PlaylistComponent::PlaylistComponent()
{
    // In your constructor, you should add any child components, and
    // initialise any special settings that your component needs.
    trackTitles.push_back("01-180813_1305");
    trackTitles.push_back("aon_inspired");
    trackTitles.push_back("bad_frog");
    trackTitles.push_back("bleep_2");
    trackTitles.push_back("bleep_10");
    trackTitles.push_back("c_major_theme");

    //Attempt to display artist names, unsuccesfful
    trackArtist.push_back("Artist1");
    trackArtist.push_back("Artist2");
    trackArtist.push_back("Artist3");
    trackArtist.push_back("Artist4");
    trackArtist.push_back("Artist5");
    trackArtist.push_back("Artist6");

    tableComponent.getHeader().addColumn("Song Title", 1, 200);
    tableComponent.getHeader().addColumn("Artist", 2, 200);
    tableComponent.getHeader().addColumn("", 3, 200);
    tableComponent.getHeader().addColumn("", 4, 200);

    

    tableComponent.setModel(this);

    addAndMakeVisible(tableComponent);
}

PlaylistComponent::~PlaylistComponent()
{
}

void PlaylistComponent::paint (juce::Graphics& g)
{
    /* This demo code just fills the component's background and
       draws some placeholder text to get you started.

       You should replace everything in this method with your own
       drawing code..
    */

    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));   // clear the background


    g.setColour (juce::Colours::grey);
    g.drawRect (getLocalBounds(), 1);   // draw an outline around the component

    g.setColour (juce::Colours::aqua);
    g.setFont (14.0f);
    g.drawText ("PlaylistComponent", getLocalBounds(),
                juce::Justification::centred, true);   // draw some placeholder text
}

void PlaylistComponent::resized()
{
    // This method is where you should set the bounds of any child
    // components that your component contains..
    tableComponent.setBounds(0, 0, getWidth(), getHeight());
}

int PlaylistComponent::getNumRows()
{
    //Here I implement the return function on the artist names in addition to the song titles
    return trackTitles.size();
    return trackArtist.size();

}

void PlaylistComponent::paintRowBackground(Graphics& g,
    int rowNumber,
    int width,
    int height,
    bool rowIsSelected)
{
    if (rowIsSelected)
    {
        g.fillAll(Colours::aqua);
    }
    else {
        g.fillAll(Colours::greenyellow);
    }
}
void PlaylistComponent::paintCell(Graphics& g,
    int rowNumber,
    int columnId,
    int width,
    int height,
    bool rowIsSelected)
{
    g.drawText(trackTitles[rowNumber],
        2, 0,
        width - 4, height,
        Justification::centredLeft, true);
 

    /*g.drawText(trackArtist[columnId = 2],
        2, 0,
        width - 4, height,
        Justification::centredLeft, true);*/

}

Component* PlaylistComponent::refreshComponentForCell(int rowNumber,
    int columnId,
    bool isRowSelected,
    Component* existingComponentToUpdate)
{
    if (columnId == 3)
    {
        if (existingComponentToUpdate == nullptr)
        {
            TextButton* btn = new TextButton{ "Load into Player 1" };
            String id{ std::to_string(rowNumber) };
            btn->setComponentID(id);

            btn->addListener(this);
            existingComponentToUpdate = btn;
        }
    }
    //Make a new player that will load it into the player 2
    else if (columnId == 4)
    {
        if (existingComponentToUpdate == nullptr)
        {
            TextButton* btn = new TextButton{ "Load into Player 2" };
            String id{ std::to_string(rowNumber) };
            btn->setComponentID(id);

            btn->addListener(this);
            existingComponentToUpdate = btn;
        }
    }

    return existingComponentToUpdate;
}

void PlaylistComponent::buttonClicked(Button* button)
//Tried implementing the loadURL function here, the result was multiple linker errors 
{
    int id = std::stoi(button->getComponentID().toStdString());
    std::cout << "b l works" << trackTitles[id] << std::endl;
}


