/*
  ==============================================================================

    MidiSeq.h
    Created: 14 Mar 2021 1:29:00pm
    Author:  nicob

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "DJAudioPlayer.h"
#include  "WaveformDisplay.h"
using namespace juce;

//==============================================================================
/*
*/
        //Here we create the class MidiMessage, and this wil be used in MidiSeq.cpp
class MidiSeq  : public juce::Component
{
public:
    MidiSeq();
    ~MidiSeq() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
//Here is the class creator
    MidiMessage midiTempo;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MidiSeq)
};


